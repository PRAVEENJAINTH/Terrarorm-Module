
variable "vms" {}