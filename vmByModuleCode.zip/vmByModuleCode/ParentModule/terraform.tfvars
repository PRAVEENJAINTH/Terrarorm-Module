rgs = {
    rg1 = {
        name = "rg1"
        location = "eastus"
    }
}

vnets = {
    vnet1 = {
        name                = "vnet1"
        address_space       = ["10.0.0.0/16"]
        resource_group_name = "rg1"
        location            = "eastus"
    }
}

subnets = {
    subnet1 = {
        name                 = "frontend"
        resource_group_name  = "rg1"
        virtual_network_name = "vnet1"
        address_prefixes     = ["10.0.1.0/24"]
    }

    subnet2 = {
        name                 = "backend"
        resource_group_name  = "rg1"
        virtual_network_name = "vnet1"
        address_prefixes     = ["10.0.2.0/24"]
    }
}


vms = {
    vm1 = {
        nic_name             = "frontend-nic"
        location             = "eastus"        
        resource_group_name  = "rg1"
        virtual_network_name = "vnets"
        subnet_name          = "frontend"
        public_ip_name       = "frontend-pip"
        name                 = "vm1"
        size                 = "Standard_B1s"
        admin_username       = "adminuser"
        admin_password       = "Devops@123"
        
    }

       vm2 = {
        nic_name             = "backend-nic"
        location             = "eastus"        
        resource_group_name  = "rg1"
        virtual_network_name = "vnets"
        subnet_name          = "backend"
        public_ip_name       = "backend-pip"
        name                 = "vm2"
        size                 = "Standard_B1s"
        admin_username       = "adminuser"
        admin_password       = "Devops@123"
        
    }
}


