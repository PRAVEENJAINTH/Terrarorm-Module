module  "resource_group" {
    
  source = "../childModule/azurerm_resource_group"
  rgs    = var.rgs
  
}

module  "vnets" {
    
  source = "../childModule/azurerm_vnet"
  vnets  = var.vnets
  
}
module "subnets" {   
  source = "../childModule/azurerm_subnet"
  subnets = var.subnets
  
}
module  "vms" {
    
  source = "../childModule/azurerm_vm"
  vms    = var.vms
  
}