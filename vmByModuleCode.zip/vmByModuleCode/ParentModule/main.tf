module  "resource_group" {
    
  source = "../childModule/azurerm_resource_group"
  rgs    = var.rgs
  
}

module "pips" {
  depends_on = [ module.resource_group ]
  source = "../childModule/azurerm_pip"
  pips = var.pips
  
}

module  "vnets" {
  depends_on = [ module.resource_group ]  
  source = "../childModule/azurerm_vnet"
  vnets  = var.vnets
  
}


module "subnets" {   
  depends_on = [ module.vnets ] 
  source = "../childModule/azurerm_subnet"
  subnet = var.subnets
  
}




module  "vms" {
  depends_on = [ module.subnets,module.pips ] 
  source = "../childModule/azurerm_vm"
  vms    = var.vms
  
}