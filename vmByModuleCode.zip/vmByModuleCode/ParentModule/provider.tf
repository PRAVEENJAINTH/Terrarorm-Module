# We strongly recommend using the required_providers block to set the
# Azure Provider source and version being used
terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "=4.1.0"
    }
  }


backend "azurerm" {
  resource_group_name  = "rg-storage"
  storage_account_name = "netfliixstoraage1"
  container_name       = "tfstate"
  key                  = "terraform.tfstate"
}
}
# Configure the Microsoft Azure Provider
provider "azurerm" {
  features {}
  subscription_id = "a0306e76-372e-4e31-9817-394046be6278"

}